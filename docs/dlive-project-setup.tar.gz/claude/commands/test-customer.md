---
description: 고객관리 기능 테스트 시나리오 실행 및 검증
---

# 고객관리 기능 테스트

고객관리 파트의 특정 기능을 테스트하고 결과를 검증합니다.

## 테스트 대상 기능 (20+ 개)

### 📋 계획 중 기능 (Phase 2+)

#### 1. 고객조회 (CM-001 ~ CM-002)
- **CM-001**: 고객 수 조회
- **CM-002**: 조건별 고객 리스트 조회

#### 2. 이력조회 (CM-003 ~ CM-005)
- **CM-003**: 상담이력 조회 (ConsultationHistory.tsx)
- **CM-004**: 작업이력 조회
- **CM-005**: 휴대폰결제 조회 (선불)

#### 3. 계약현황 (CM-006 ~ CM-008)
- **CM-006**: 계약 정보 카운트 조회
- **CM-007**: 고객 계약 전체 조회
- **CM-008**: 상품 프로모션 정보

#### 4. 청구/결제 (CM-009 ~ CM-010)
- **CM-009**: 청구매체 변경 신청
- **CM-010**: 카드 Key-in 결제

#### 5. 정보변경 (CM-011 ~ CM-014)
- **CM-011**: 전화번호 변경
- **CM-012**: 설치지주소 변경
- **CM-013**: 고객주소 변경
- **CM-014**: 청구지주소 변경

#### 6. 상담등록 (CM-015 ~ CM-016)
- **CM-015**: 상담이력 등록
- **CM-016**: AS 접수 등록

---

## 카테고리별 테스트

### 1. 고객조회 (CM-001 ~ CM-002)

#### CM-001: 고객 수 조회
```bash
# API 테스트
curl -X POST http://localhost:3000/api/customer/negociation/getCustCntBySearchCust \
  -H "Content-Type: application/json" \
  -d '{
    "SEARCH_TYPE": "TEL",
    "SEARCH_VALUE": "01012345678"
  }'
```

**예상 결과**:
- ✅ HTTP 200 응답
- ✅ 고객 수 반환
- ✅ 필드: CUST_CNT (숫자)

**제약사항**:
- ❌ 고객명 단독 검색 불가
- ✅ 전화번호/주소/계약번호/장비번호로만 검색 가능

**UI 테스트**:
1. 고객관리 메뉴 클릭
2. 검색 타입 선택 (전화번호)
3. 전화번호 입력: 010-1234-5678
4. "검색" 버튼 클릭
5. 고객 수 표시 확인
6. "상세 조회" 버튼 활성화 (고객 수 > 0)

#### CM-002: 조건별 고객 리스트 조회
```bash
# API 테스트
curl -X POST http://localhost:3000/api/customer/common/customercommon/getConditionalCustList2 \
  -H "Content-Type: application/json" \
  -d '{
    "CUST_NM": "홍길동",
    "TEL_NO": "01012345678",
    "ADDR": "서울",
    "CNTR_ID": ""
  }'
```

**예상 결과**:
- ✅ 고객 리스트 배열 반환
- ✅ 필드: CUST_ID, CUST_NM, TEL_NO, ADDR, CNTR_CNT

**UI 테스트**:
1. 다중 조건 검색 화면
2. 고객명: "홍길동"
3. 전화번호: "010-1234-5678"
4. 주소: "서울"
5. "검색" 버튼 클릭
6. 고객 리스트 표시 확인 (최대 100건)
7. 고객 클릭 → 상세 화면 이동

---

### 2. 이력조회 (CM-003 ~ CM-005)

#### CM-003: 상담이력 조회
```bash
# API 테스트
curl -X POST http://localhost:3000/api/customer/negociation/getCallHistory \
  -H "Content-Type: application/json" \
  -d '{
    "CUST_ID": "CUST123456",
    "LIMIT": 10
  }'
```

**예상 결과**:
- ✅ 상담 이력 배열 반환 (최근 10건)
- ✅ 필드: CNSL_DT, CNSL_TYPE_NM, CNSL_CONTENT, WRKR_NM

**UI 테스트**:
1. 고객 상세 화면
2. "상담이력" 탭 클릭
3. 최근 10건 기본 표시
4. "전체 보기" 버튼 클릭
5. 전체 상담 이력 표시
6. 날짜 내림차순 정렬 확인

#### CM-004: 작업이력 조회
```bash
# API 테스트
curl -X POST http://localhost:3000/api/customer/negociation/getCustWorkList \
  -H "Content-Type: application/json" \
  -d '{
    "CUST_ID": "CUST123456",
    "WORK_DT_FROM": "20250101",
    "WORK_DT_TO": "20250131"
  }'
```

**예상 결과**:
- ✅ 작업 이력 배열 반환
- ✅ 필드: WORK_DT, PROD_NM, WORK_TYPE_NM, WORK_STS_NM, WRKR_NM

**UI 테스트**:
1. 고객 상세 화면
2. "작업이력" 탭 클릭
3. 날짜 범위 선택
4. 작업 이력 리스트 표시 확인
5. 작업 항목 클릭 → 작업 상세 화면 이동

---

### 3. 계약현황 (CM-006 ~ CM-008)

#### CM-006: 계약 정보 카운트 조회
```bash
# API 테스트
curl -X POST http://localhost:3000/api/customer/negociation/getCustCtrtInfoListCnt_1 \
  -H "Content-Type: application/json" \
  -d '{
    "CUST_ID": "CUST123456"
  }'
```

**예상 결과**:
- ✅ 상품군별 계약 건수 배열
- ✅ 필드:
  - PROD_GRP_NM: "인터넷" / "TV" / "전화"
  - USE_CNT: 사용중 건수
  - TERM_CNT: 해지 건수
  - TOTAL_CNT: 합계 건수

**UI 테스트**:
1. 고객 상세 화면
2. "계약현황" 탭 클릭
3. 상품군별 계약 건수 표시 확인
   - 인터넷: 사용 2건 / 해지 1건 / 총 3건
   - TV: 사용 1건 / 해지 0건 / 총 1건
   - 전화: 사용 1건 / 해지 0건 / 총 1건

#### CM-007: 고객 계약 전체 조회
```bash
# API 테스트
curl -X POST http://localhost:3000/api/customer/negociation/getCustCtrtAll \
  -H "Content-Type: application/json" \
  -d '{
    "CUST_ID": "CUST123456",
    "INCLUDE_TERMINATED": true
  }'
```

**예상 결과**:
- ✅ 계약 리스트 배열 반환
- ✅ 필드: CNTR_ID, PROD_NM, CNTR_DT, TERM_DT, CNTR_STS_NM, MONTHLY_FEE

**UI 테스트**:
1. "계약현황" 탭에서 상품군 클릭
2. 해당 상품군의 계약 상세 리스트 표시
3. "해지 포함" 체크박스 선택
4. 해지 계약도 함께 표시 확인
5. 계약 클릭 → 계약 상세 정보 모달

---

### 4. 청구/결제 (CM-009 ~ CM-010)

#### CM-009: 청구매체 변경 신청
```bash
# API 테스트
curl -X POST http://localhost:3000/api/customer/customer/general/customerPymChgAddManager \
  -H "Content-Type: application/json" \
  -d '{
    "CUST_ID": "CUST123456",
    "PYM_TYPE": "AUTO",
    "BANK_CD": "004",
    "ACCT_NO": "123456789012",
    "ACCT_HOLDER": "홍길동"
  }'
```

**예상 결과**:
- ✅ 성공 메시지 반환
- ✅ RESULT_CODE: "0000"
- ✅ CHANGE_NO: 변경 신청 번호

**UI 테스트**:
1. 고객 상세 화면
2. "청구/결제" 탭 클릭
3. "청구매체 변경" 버튼 클릭
4. 변경 정보 입력
   - 결제 방법: 자동이체
   - 은행: 국민은행
   - 계좌번호: 123-456-789012
   - 예금주: 홍길동
5. "신청" 버튼 클릭
6. 확인 다이얼로그 표시
7. "확인" 클릭
8. 성공 메시지 확인

#### CM-010: 카드 Key-in 결제
```
⚠️ 이 기능은 Phase 3 계획
PG 연동 필요
실제 카드 결제 테스트 주의
```

---

### 5. 정보변경 (CM-011 ~ CM-014)

#### CM-011: 전화번호 변경
```bash
# API 테스트
curl -X POST http://localhost:3000/api/customer/negociation/updateCustTelDetailInfo \
  -H "Content-Type: application/json" \
  -d '{
    "CUST_ID": "CUST123456",
    "OLD_TEL_NO": "01012345678",
    "NEW_TEL_NO": "01098765432",
    "AUTH_NO": "123456"
  }'
```

**예상 결과**:
- ✅ 성공 메시지
- ✅ RESULT_CODE: "0000"

**제약사항**:
- ❗ 난수 인증번호 확인 필수

**UI 테스트**:
1. 고객 상세 화면
2. "정보변경" 탭 클릭
3. "전화번호 변경" 버튼 클릭
4. 현재 전화번호 표시: 010-1234-5678
5. 새 전화번호 입력: 010-9876-5432
6. "인증번호 발송" 버튼 클릭
7. SMS 발송 확인 메시지
8. 인증번호 입력: 123456
9. "변경" 버튼 클릭
10. 성공 메시지 확인
11. 변경된 전화번호 표시 확인

#### CM-012: 설치지주소 변경
```bash
# API 테스트
curl -X POST http://localhost:3000/api/customer/etc/saveMargeAddrOrdInfo \
  -H "Content-Type: application/json" \
  -d '{
    "CUST_ID": "CUST123456",
    "ADDR_TYPE": "INSTALL",
    "POST_NO": "06234",
    "BASE_ADDR": "서울특별시 강남구 테헤란로 123",
    "DETAIL_ADDR": "456호"
  }'
```

**예상 결과**:
- ✅ 성공 메시지
- ✅ 변경된 주소 정보 반환

**UI 테스트**:
1. "정보변경" 탭
2. "설치지주소 변경" 버튼 클릭
3. 현재 주소 표시
4. "우편번호 검색" 버튼 클릭
5. 주소 검색 모달 표시
6. 주소 검색: "테헤란로 123"
7. 검색 결과에서 주소 선택
8. 상세주소 입력: "456호"
9. "변경" 버튼 클릭
10. 성공 메시지 확인

---

### 6. 상담등록 (CM-015 ~ CM-016)

#### CM-015: 상담이력 등록
```bash
# API 테스트
curl -X POST http://localhost:3000/api/customer/negociation/saveCnslRcptInfo \
  -H "Content-Type: application/json" \
  -d '{
    "CUST_ID": "CUST123456",
    "CNSL_TYPE_CD": "10",
    "CNSL_DTL_TYPE_CD": "101",
    "CNSL_CONTENT": "인터넷 속도 저하 문의",
    "PROC_TYPE_CD": "20",
    "PROC_DEPT_CD": "AS팀"
  }'
```

**예상 결과**:
- ✅ 성공 메시지
- ✅ CNSL_NO: 상담 접수 번호

**UI 테스트**:
1. 고객 상세 화면
2. "상담등록" 버튼 클릭
3. 상담 소분류 선택
   - 대분류: 장애/문의
   - 소분류: 인터넷 속도 저하
4. 상담 내용 입력
5. 전달 처리 선택
   - 처리 부서: AS팀
   - 요청사항: 빠른 처리 부탁
6. "등록" 버튼 클릭
7. 성공 메시지 확인
8. 상담이력 탭에서 등록된 내용 확인

#### CM-016: AS 접수 등록
```bash
# API 테스트
curl -X POST http://localhost:3000/api/customer/work/modAsPdaReceipt \
  -H "Content-Type: application/json" \
  -d '{
    "CUST_ID": "CUST123456",
    "CNTR_ID": "CNTR123456",
    "AS_TYPE_CD": "10",
    "AS_CONTENT": "인터넷 불통",
    "HOPE_DT": "20250130",
    "HOPE_TIME": "14:00"
  }'
```

**예상 결과**:
- ✅ AS 접수 성공
- ✅ WORK_DRCTN_NO: 작업지시 번호

**UI 테스트**:
1. 고객 상세 화면
2. "AS 접수" 버튼 클릭
3. 계약 선택 (고객이 여러 계약 보유 시)
4. AS 유형 선택: 인터넷 불통
5. 증상 입력: "인터넷 연결 안 됨"
6. 희망 방문 일시 선택
   - 날짜: 2025-01-30
   - 시간: 14:00
7. "접수" 버튼 클릭
8. 확인 다이얼로그 표시
9. "확인" 클릭
10. 접수 완료 메시지 + 작업지시번호 표시
11. "작업 보기" 버튼 → 작업 상세 화면 이동

---

## 테스트 시나리오

### 시나리오 1: 고객 검색 → 상담 등록 → AS 접수

```
1. 고객 검색 (CM-001)
   → 전화번호: 010-1234-5678
   → 고객 수: 1명

2. 고객 리스트 조회 (CM-002)
   → 고객명: 홍길동
   → 주소: 서울특별시 강남구...
   → 계약 수: 3건

3. 고객 상세 화면
   → 계약현황 탭 (CM-006, CM-007)
   → 인터넷: 2건 (사용중)
   → TV: 1건 (사용중)

4. 상담이력 조회 (CM-003)
   → 최근 10건 표시
   → 최근 상담: 2025-01-15 "요금 문의"

5. 상담 등록 (CM-015)
   → 대분류: 장애/문의
   → 소분류: 인터넷 속도 저하
   → 내용: "저녁 시간대 속도 느림"
   → 전달: AS팀

6. AS 접수 (CM-016)
   → 계약 선택: 인터넷 100M
   → AS 유형: 인터넷 불통
   → 희망 일시: 2025-01-30 14:00
   → 접수 완료: WD202501300001

7. 작업 확인
   → 작업관리 화면으로 이동
   → 신규 작업 확인
```

### 시나리오 2: 고객 정보 변경

```
1. 고객 검색 및 상세
2. "정보변경" 탭 클릭
3. 전화번호 변경 (CM-011)
   → 인증번호 발송 → 입력 → 변경
4. 설치지주소 변경 (CM-012)
   → 우편번호 검색 → 상세주소 입력 → 변경
5. 청구지주소 변경 (CM-014)
   → 설치지와 동일 체크박스 → 자동 입력 → 변경
6. 변경 내역 확인
   → 고객 정보 업데이트 확인
```

---

## 자동화 테스트 스크립트

```bash
#!/bin/bash
# test-customer-features.sh

echo "🧪 고객관리 기능 테스트 시작..."

# CM-001: 고객 수 조회
echo ""
echo "1. CM-001: 고객 수 조회"
RESULT=$(curl -s -X POST http://localhost:3000/api/customer/negociation/getCustCntBySearchCust \
  -H "Content-Type: application/json" \
  -d '{"SEARCH_TYPE":"TEL","SEARCH_VALUE":"01012345678"}')

if [ $? -eq 0 ]; then
  CNT=$(echo $RESULT | jq -r '.CUST_CNT')
  echo "✅ 성공: $CNT 명"
else
  echo "❌ 실패"
fi

# CM-003: 상담이력 조회
echo ""
echo "2. CM-003: 상담이력 조회"
RESULT=$(curl -s -X POST http://localhost:3000/api/customer/negociation/getCallHistory \
  -H "Content-Type: application/json" \
  -d '{"CUST_ID":"CUST123456","LIMIT":10}')

if [ $? -eq 0 ]; then
  echo "✅ 성공: $(echo $RESULT | jq 'length') 건"
else
  echo "❌ 실패"
fi

echo ""
echo "✅ 고객관리 테스트 완료"
```

---

## 출력 형식

```
🧪 테스트: CM-001 고객 수 조회

✅ 1. API 테스트
- Endpoint: /customer/negociation/getCustCntBySearchCust
- Method: POST
- Parameters: {
    SEARCH_TYPE: "TEL",
    SEARCH_VALUE: "01012345678"
  }
- Response: { CUST_CNT: 1 }
- Status: ✅ 성공 (200 OK, 234ms)

✅ 2. UI 테스트
- 검색 타입: 전화번호
- 검색어: 010-1234-5678
- 결과: 1명
- 상세 조회 버튼: ✅ 활성화

✅ 3. 검증 결과
- 응답 시간: 234ms
- 고객 수: 1명
- 에러 케이스: ✅ 처리됨 (고객명 단독 검색 시 에러 메시지)

📋 종합 평가: ✅ 통과
```

---

## 주의사항

- 고객명 단독 검색 불가 (시스템 제약)
- 인증번호 발송은 실제 SMS 발송됨 (테스트 주의)
- 청구매체 변경은 실제 DB 변경 (신중히 테스트)
- 카드 결제는 Phase 3 (현재 미구현)
- 주소 변경 시 우편번호 API 연동 확인

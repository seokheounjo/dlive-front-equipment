import React, { useState, useEffect } from 'react';

interface ApiCall {
  id: string;
  timestamp: string;
  method: string;
  url: string;
  params: any;
  response: any;
  error: string | null;
  duration: number;
  status: 'success' | 'error' | 'pending';
}

interface ApiEndpoint {
  id: string;
  category: string;
  name: string;
  path: string;
  description: string;
  params: {
    name: string;
    type: string;
    required: boolean;
    default?: any;
  }[];
}

const API_ENDPOINTS: ApiEndpoint[] = [
  // 장비관리 - 장비상태조회
  {
    id: 'getEquipmentHistoryInfo',
    category: '장비관리',
    name: '장비 이력 조회',
    path: '/statistics/equipment/getEquipmentHistoryInfo',
    description: 'S/N 또는 MAC으로 장비 정보 조회 (75개 필드)',
    params: [
      { name: 'EQT_SERNO', type: 'string', required: false },
      { name: 'MAC_ADDRESS', type: 'string', required: false },
    ],
  },
  // 장비관리 - 장비할당/반납
  {
    id: 'getEquipmentOutList',
    category: '장비관리',
    name: '기사할당 장비 조회',
    path: '/customer/equipment/getEquipmentOutList',
    description: '출고일자/지점별 파트너사 출고현황',
    params: [
      { name: 'OUT_DT', type: 'string', required: false, default: '20250128' },
      { name: 'SO_ID', type: 'string', required: false },
    ],
  },
  {
    id: 'getEquipmentReturnRequestList',
    category: '장비관리',
    name: '기사 보유장비 조회',
    path: '/customer/equipment/getEquipmentReturnRequestList',
    description: '작업자 ID/MAC별 장비 조회',
    params: [
      { name: 'WRKR_ID', type: 'string', required: false },
      { name: 'MAC_ADDRESS', type: 'string', required: false },
    ],
  },
  // 장비관리 - 미회수장비회수
  {
    id: 'getEquipLossInfo',
    category: '장비관리',
    name: '미회수 장비 조회',
    path: '/customer/work/getEquipLossInfo',
    description: '지점/S/N/계약ID별 조회',
    params: [
      { name: 'SO_ID', type: 'string', required: false },
      { name: 'EQT_SERNO', type: 'string', required: false },
      { name: 'CNTR_ID', type: 'string', required: false },
    ],
  },
  // 공통코드
  {
    id: 'getCodeDetail',
    category: '공통',
    name: '공통코드 조회',
    path: '/system/cm/getCodeDetail',
    description: '코드 그룹별 코드 목록',
    params: [
      { name: 'GRP_CD', type: 'string', required: true, default: 'EQT_STS' },
    ],
  },
  // 작업관리
  {
    id: 'getTodayWorkList',
    category: '작업관리',
    name: '오늘 작업 목록',
    path: '/customer/work/getTodayWorkList',
    description: '당일 배정된 작업 목록',
    params: [
      { name: 'WORK_DT', type: 'string', required: false },
      { name: 'WRKR_ID', type: 'string', required: false },
    ],
  },
];

const ApiExplorer: React.FC = () => {
  const [selectedEndpoint, setSelectedEndpoint] = useState<ApiEndpoint | null>(null);
  const [paramValues, setParamValues] = useState<Record<string, any>>({});
  const [apiCalls, setApiCalls] = useState<ApiCall[]>([]);
  const [selectedCall, setSelectedCall] = useState<ApiCall | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [filter, setFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('전체');

  // localStorage에서 이전 API 호출 기록 복원
  useEffect(() => {
    const savedCalls = localStorage.getItem('apiExplorer_calls');
    if (savedCalls) {
      try {
        setApiCalls(JSON.parse(savedCalls));
      } catch (e) {
        console.error('Failed to restore API calls', e);
      }
    }
  }, []);

  // API 호출 기록 저장
  useEffect(() => {
    localStorage.setItem('apiExplorer_calls', JSON.stringify(apiCalls));
  }, [apiCalls]);

  // 엔드포인트 선택 시 기본값 설정
  useEffect(() => {
    if (selectedEndpoint) {
      const defaults: Record<string, any> = {};
      selectedEndpoint.params.forEach((param) => {
        if (param.default !== undefined) {
          defaults[param.name] = param.default;
        }
      });
      setParamValues(defaults);
    }
  }, [selectedEndpoint]);

  const handleParamChange = (paramName: string, value: any) => {
    setParamValues((prev) => ({
      ...prev,
      [paramName]: value,
    }));
  };

  const handleCallApi = async () => {
    if (!selectedEndpoint) return;

    const callId = `${Date.now()}-${Math.random()}`;
    const startTime = performance.now();

    const newCall: ApiCall = {
      id: callId,
      timestamp: new Date().toISOString(),
      method: 'POST',
      url: selectedEndpoint.path,
      params: { ...paramValues },
      response: null,
      error: null,
      duration: 0,
      status: 'pending',
    };

    setApiCalls((prev) => [newCall, ...prev]);
    setSelectedCall(newCall);
    setIsLoading(true);

    try {
      const response = await fetch(`/api${selectedEndpoint.path}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(paramValues),
      });

      const endTime = performance.now();
      const duration = endTime - startTime;

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();

      setApiCalls((prev) =>
        prev.map((call) =>
          call.id === callId
            ? {
                ...call,
                response: data,
                duration: Math.round(duration),
                status: 'success',
              }
            : call
        )
      );

      setSelectedCall({
        ...newCall,
        response: data,
        duration: Math.round(duration),
        status: 'success',
      });
    } catch (error: any) {
      const endTime = performance.now();
      const duration = endTime - startTime;

      setApiCalls((prev) =>
        prev.map((call) =>
          call.id === callId
            ? {
                ...call,
                error: error.message,
                duration: Math.round(duration),
                status: 'error',
              }
            : call
        )
      );

      setSelectedCall({
        ...newCall,
        error: error.message,
        duration: Math.round(duration),
        status: 'error',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearHistory = () => {
    if (confirm('모든 API 호출 기록을 삭제하시겠습니까?')) {
      setApiCalls([]);
      setSelectedCall(null);
      localStorage.removeItem('apiExplorer_calls');
    }
  };

  const handleExportJson = () => {
    const dataStr = JSON.stringify(apiCalls, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);

    const exportFileDefaultName = `api-calls-${new Date().toISOString().slice(0, 10)}.json`;

    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleExportCsv = () => {
    const headers = ['Timestamp', 'Method', 'URL', 'Status', 'Duration (ms)', 'Error'];
    const rows = apiCalls.map((call) => [
      call.timestamp,
      call.method,
      call.url,
      call.status,
      call.duration,
      call.error || '',
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map((row) => row.map((cell) => `"${cell}"`).join(',')),
    ].join('\n');

    const dataUri = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvContent);
    const exportFileDefaultName = `api-calls-${new Date().toISOString().slice(0, 10)}.csv`;

    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const filteredEndpoints = API_ENDPOINTS.filter((endpoint) => {
    const matchesSearch =
      filter === '' ||
      endpoint.name.toLowerCase().includes(filter.toLowerCase()) ||
      endpoint.path.toLowerCase().includes(filter.toLowerCase());

    const matchesCategory = categoryFilter === '전체' || endpoint.category === categoryFilter;

    return matchesSearch && matchesCategory;
  });

  const categories = ['전체', ...Array.from(new Set(API_ENDPOINTS.map((e) => e.category)))];

  const filteredCalls = apiCalls.filter((call) => {
    if (filter === '') return true;
    return (
      call.url.toLowerCase().includes(filter.toLowerCase()) ||
      JSON.stringify(call.params).toLowerCase().includes(filter.toLowerCase())
    );
  });

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">API Explorer</h1>
          <p className="text-gray-600 mt-2">D-Live 장비관리 시스템 API 테스트 도구</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Panel - Endpoints */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow p-4">
              <h2 className="text-xl font-bold mb-4">API 엔드포인트</h2>

              {/* Category Filter */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">카테고리</label>
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              {/* Search */}
              <div className="mb-4">
                <input
                  type="text"
                  placeholder="검색..."
                  value={filter}
                  onChange={(e) => setFilter(e.target.value)}
                  className="w-full border border-gray-300 rounded px-3 py-2"
                />
              </div>

              {/* Endpoint List */}
              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {filteredEndpoints.map((endpoint) => (
                  <button
                    key={endpoint.id}
                    onClick={() => setSelectedEndpoint(endpoint)}
                    className={`w-full text-left p-3 rounded border ${
                      selectedEndpoint?.id === endpoint.id
                        ? 'bg-blue-50 border-blue-500'
                        : 'bg-white border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <div className="font-medium text-sm">{endpoint.name}</div>
                    <div className="text-xs text-gray-500 mt-1">{endpoint.path}</div>
                    <div className="text-xs text-gray-400 mt-1">{endpoint.category}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Middle Panel - Request Builder */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow p-4">
              <h2 className="text-xl font-bold mb-4">요청 설정</h2>

              {selectedEndpoint ? (
                <>
                  <div className="mb-4">
                    <h3 className="font-medium text-lg">{selectedEndpoint.name}</h3>
                    <p className="text-sm text-gray-600 mt-1">{selectedEndpoint.description}</p>
                    <code className="block bg-gray-100 p-2 rounded mt-2 text-sm">
                      POST {selectedEndpoint.path}
                    </code>
                  </div>

                  <div className="mb-4">
                    <h4 className="font-medium mb-2">파라미터</h4>
                    {selectedEndpoint.params.length > 0 ? (
                      <div className="space-y-3">
                        {selectedEndpoint.params.map((param) => (
                          <div key={param.name}>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              {param.name}
                              {param.required && <span className="text-red-500 ml-1">*</span>}
                              <span className="text-gray-400 ml-2 text-xs">({param.type})</span>
                            </label>
                            <input
                              type="text"
                              value={paramValues[param.name] || ''}
                              onChange={(e) => handleParamChange(param.name, e.target.value)}
                              className="w-full border border-gray-300 rounded px-3 py-2"
                              placeholder={param.default?.toString() || ''}
                            />
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-gray-500">파라미터 없음</p>
                    )}
                  </div>

                  <button
                    onClick={handleCallApi}
                    disabled={isLoading}
                    className="w-full bg-blue-600 text-white py-3 rounded font-medium hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
                  >
                    {isLoading ? '호출 중...' : 'API 호출'}
                  </button>
                </>
              ) : (
                <p className="text-gray-500 text-center py-8">
                  왼쪽에서 API 엔드포인트를 선택하세요
                </p>
              )}
            </div>

            {/* Response Panel */}
            {selectedCall && (
              <div className="bg-white rounded-lg shadow p-4 mt-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-medium">응답</h3>
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-1 rounded text-xs font-medium ${
                        selectedCall.status === 'success'
                          ? 'bg-green-100 text-green-800'
                          : selectedCall.status === 'error'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}
                    >
                      {selectedCall.status}
                    </span>
                    <span className="text-xs text-gray-500">{selectedCall.duration}ms</span>
                  </div>
                </div>

                {selectedCall.error ? (
                  <div className="bg-red-50 border border-red-200 rounded p-3 text-red-700 text-sm">
                    {selectedCall.error}
                  </div>
                ) : selectedCall.response ? (
                  <div className="bg-gray-50 rounded p-3 max-h-[400px] overflow-y-auto">
                    <pre className="text-xs">{JSON.stringify(selectedCall.response, null, 2)}</pre>
                  </div>
                ) : (
                  <p className="text-gray-500 text-sm">호출 대기 중...</p>
                )}
              </div>
            )}
          </div>

          {/* Right Panel - History */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow p-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold">호출 기록</h2>
                <div className="flex gap-2">
                  <button
                    onClick={handleExportJson}
                    className="text-xs bg-gray-200 px-2 py-1 rounded hover:bg-gray-300"
                    disabled={apiCalls.length === 0}
                  >
                    JSON
                  </button>
                  <button
                    onClick={handleExportCsv}
                    className="text-xs bg-gray-200 px-2 py-1 rounded hover:bg-gray-300"
                    disabled={apiCalls.length === 0}
                  >
                    CSV
                  </button>
                  <button
                    onClick={handleClearHistory}
                    className="text-xs bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600"
                    disabled={apiCalls.length === 0}
                  >
                    초기화
                  </button>
                </div>
              </div>

              <div className="space-y-2 max-h-[800px] overflow-y-auto">
                {filteredCalls.length > 0 ? (
                  filteredCalls.map((call) => (
                    <button
                      key={call.id}
                      onClick={() => setSelectedCall(call)}
                      className={`w-full text-left p-3 rounded border ${
                        selectedCall?.id === call.id
                          ? 'bg-blue-50 border-blue-500'
                          : 'bg-white border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-gray-500">
                          {new Date(call.timestamp).toLocaleTimeString('ko-KR')}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded text-xs font-medium ${
                            call.status === 'success'
                              ? 'bg-green-100 text-green-800'
                              : call.status === 'error'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-yellow-100 text-yellow-800'
                          }`}
                        >
                          {call.duration}ms
                        </span>
                      </div>
                      <div className="text-sm font-medium truncate">{call.url}</div>
                      {call.error && (
                        <div className="text-xs text-red-600 truncate mt-1">{call.error}</div>
                      )}
                    </button>
                  ))
                ) : (
                  <p className="text-gray-500 text-center py-8 text-sm">호출 기록이 없습니다</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApiExplorer;
